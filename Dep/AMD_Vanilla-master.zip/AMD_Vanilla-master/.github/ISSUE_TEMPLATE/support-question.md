---
name: Support question
about: If you have a support question, please go to the discord or the forum.
title: ''
labels: invalid, unrelated, support
assignees: ''

---

If you have a support question, please go to the discord or the forum.
