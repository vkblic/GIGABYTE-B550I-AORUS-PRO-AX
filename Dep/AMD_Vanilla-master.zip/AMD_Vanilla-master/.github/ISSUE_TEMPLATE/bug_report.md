---
name: Bug report
about: Report a bug with the patches. NOT for support questions.
title: ''
labels: ''
assignees: ''

---

**CPU:**
**macOS version:**
**15h/16h or 17h:**
**I am using and can reproduce on the latest patches:**

**Describe the bug**
A clear and concise description of what the bug is.

**Screenshots**
If applicable, add screenshots to help explain your problem.
